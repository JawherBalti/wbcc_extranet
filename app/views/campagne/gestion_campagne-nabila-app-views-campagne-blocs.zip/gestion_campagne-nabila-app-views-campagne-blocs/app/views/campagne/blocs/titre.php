<div
    style="margin-top:15px; padding:10px; border: 1px solid #36B9CC; border-radius: 20px;     background-color: #fff; text-align: center;">
    <h2><span><?=$icon?></span> <?=$titre?>
        <img style="height: 38px;" src="<?= URLROOT . $imgUrl?>" alt="">
    </h2>
</div>